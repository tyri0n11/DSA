package JavaOOP.Reinforcement;

class State extends Region {
    State() { }
    public void printMe() {
        System.out.println("Ship it.");
    }
}
