package JavaOOP.Reinforcement;

class Region extends Place {
    Region() { }
    public void printMe() {
        System.out.println("Box it.");
    }
}
