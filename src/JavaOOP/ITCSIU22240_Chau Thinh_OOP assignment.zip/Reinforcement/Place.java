package JavaOOP.Reinforcement;

public class Place extends Object {
    Place() { }
    public void printMe() {
        System.out.println("Buy it.");
    }
}
